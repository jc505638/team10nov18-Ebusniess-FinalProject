<?php

class Category extends Brightery_Controller
{

    public $layout = 'full';
    public $module = 'home';
    public $model = 'articles_model';

    public function __construct()
    {
        parent::__construct();
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];

    }

    public function index($id = null, $offset = 0)
    {
        if (!$id)
            show_404();
        $title = $id;
        $id = (int) $id;
//        $data['title'] = $title;
        $data['_real_articles'] = array();
        $data['real_articles'] = array();

        $category = $this->db->where('category_id', $id)->get('categories')->row();


        if (!$category)
            show_404();
        $keywords = $this->db->where('category_id', $category->category_id)->get('keywords')->row();
        if (isset($keywords->page_title))
            config('title', $keywords->page_title);
        if (isset($keywords->page_description))
            config('meta_description', $keywords->page_description);
        if (isset($keywords->page_keywords))
            config('meta_keywords', $keywords->page_keywords);

//        config('title', $category->title);
        $this->load->library('pagination');
        $this->{$this->model}->{'categories.category_id'} = $id;
        $this->{$this->model}->{'articles.custom'} = '0';
        $this->{$this->model}->custom_select = 'articles.*, categories.title as name, categories.category_id';
        $this->{$this->model}->joins = array(
            'categories' => array('categories.category_id = articles.category_id', 'inner')
        );
        $config['base_url'] = site_url('category/' . $title);
        $config['total_rows'] = $this->{$this->model}->get(TRUE);
        $config['per_page'] = config('pagination_limit');
        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->{$this->model}->limit = config('pagination_limit');
        $this->{$this->model}->offset = $offset;
        $data['items'] = $this->{$this->model}->get();
        // CATEGORY SLIDERS
        $data['sliders'] = $this->db->where('category_id', $category->category_id)->order_by('slider_id', 'desc')->get('sliders')->result();

        $this->db->select('articles.*, categories.title as name');
        $this->db->order_by('articles.article_id', 'DESC');
        $this->db->where('articles.custom', '1');
        $this->db->where('categories.category_id', $category->category_id);
        $this->db->join('categories', 'categories.category_id = articles.category_id');
        $data['real_articles'] = $this->db->get('articles', 10)->result();

        // CATEGORY BANNERS
        $limit = floor(count($data['items']) / config('ad'));
        $this->db->order_by('banners.order', 'ASC');
        $this->db->where('banner_categories.category_id', $category->category_id);
        $this->db->join('banner_categories', 'banner_categories.banner_id = banners.banner_id');
        $data['ads'] = $this->db->get('banners', $limit)->result();

        $this->load->view($this->module, $data);
    }


}
