<?php

class Dashboard extends CI_Controller {
    public $layout = 'full';
    public $module = 'dashboard';
   public $model = 'Categories_model';

   public function index() {
        $data['items'] = $this->db->select('categories.*, (SELECT COUNT(*) FROM articles WHERE articles.category_id = categories.category_id) AS count')->where('parent', '0')->order_by('order', 'ASC')->get('categories')->result();
        $this->load->view($this->module, $data);
    }

}