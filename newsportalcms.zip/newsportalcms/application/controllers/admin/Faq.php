<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Faq extends CI_Controller {

    public $module = "faq";

    public function __construct() {
        parent::__construct();
        $this->load->model('faq_model');
        $this->lang->load('faq');
        $this->output->enable_profiler(FALSE);
        permission();
    }

    public function index() {
        if (isset($_GET['search']))
            $this->search();
        $data["total_rows"] = $this->faq_model->get(true);
        $this->faq_model->offset = $this->uri->segment("4");
        $this->faq_model->limit = config('per_page');
        $data["items"] = $this->faq_model->get();
        $config['uri_segment'] = 4;
        $config['base_url'] = site_url('admin/faq/index');
        $config['total_rows'] = $data["total_rows"];
        $config['per_page'] = $this->faq_model->limit;
        $config['suffix'] = $this->input->get() ? '?' . http_build_query($_GET) : NULL;
        $this->load->library('pagination');
        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('admin/faq/index', $data);
        $this->report->set('{report_view_faq}' . current_url());
    }

    public function manage($id = FALSE) {
        if (!$id) {
            permission($this->module . '/add');
            $data['item'] = new stdClass();
            $data['item']->question = NULL;
            $data['item']->answer = NULL;
        } else {
            permission($this->module . '/edit');
            $this->faq_model->faq_id = $id;
            $data['item'] = $this->faq_model->get();
            if (!$data['item'])
                show_404();
        }
        $this->load->library("form_validation");
        $this->form_validation->set_rules("question", 'lang:faq_question', "trim|required");
        $this->form_validation->set_rules("answer", 'lang:faq_answer', "trim|required");
        if ($this->form_validation->run() == false) {
            $this->load->view("admin/faq/manage", $data);
        } else {
            $this->faq_model->question = $this->input->post('question');
            $this->faq_model->answer = $this->input->post('answer');
            $faq_id = $this->faq_model->save();
            if ($id)
                $this->report->set('{report_update_faq} #' . $id);
            else
                $this->report->set('{report_insert_faq} #' . $faq_id);
            redirect("admin/faq/index");
        }
    }

    public function delete($id = false) {
        permission($this->module . '/delete');
        if (!$id)
            show_404();
        $this->faq_model->faq_id = $id;
        if ($this->input->get("question"))
            $this->faq_model->question = $this->input->get("question");
        if ($this->input->get("answer"))
            $this->faq_model->answer = $this->input->get("answer");

        if (!$this->faq_model->delete())
            show_404();
        $this->report->set('{report_delete_faq} #' . $id);
        redirect("admin/faq/index");
    }

    public function search() {
        if ($this->input->get("faq_id"))
            $this->faq_model->faq_id = $this->input->get("faq_id");
        if ($this->input->get("question"))
            $this->faq_model->question = $this->input->get("question");
        if ($this->input->get("answer"))
            $this->faq_model->answer = $this->input->get("answer");
    }

}

/* End of file faq.php */
/* Location: ./application/controllers/admin/faq.php */