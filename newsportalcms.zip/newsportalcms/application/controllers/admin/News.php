<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class News extends CI_Controller {

    public $module = "news";

    public function __construct() {
        parent::__construct();
        $this->load->model('news_model');
        $this->lang->load('news');
        $this->output->enable_profiler(FALSE);
        permission();
    }

    public function index() {
        if (isset($_GET['search']))
            $this->search();
        $data["total_rows"] = $this->news_model->get(true);
        $this->news_model->offset = $this->uri->segment("4");
        $this->news_model->limit = config('per_page');
        $data["items"] = $this->news_model->get();
        $config['uri_segment'] = 4;
        $config['base_url'] = site_url('admin/news/index');
        $config['total_rows'] = $data["total_rows"];
        $config['per_page'] = $this->news_model->limit;
        $config['suffix'] = $this->input->get() ? '?' . http_build_query($_GET) : NULL;
        $this->load->library('pagination');
        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('admin/news/index', $data);
        $this->report->set('{report_view_news}' . current_url());
    }

    public function manage($id = FALSE) {
        if (!$id) {
            $data['item'] = new stdClass();
            $data['item']->title = NULL;
            $data['item']->content = NULL;
            $data['item']->datetime = NULL;
            $data['item']->image = NULL;
        } else {
            $this->news_model->news_id = $id;
            $data['item'] = $this->news_model->get();
            if (!$data['item'])
                show_404();
        }
        $this->load->library("form_validation");
        $this->form_validation->set_rules("title", 'lang:news_title', "trim|required");
        $this->form_validation->set_rules("content", 'lang:news_content', "trim|required");
        $this->form_validation->set_rules("image", 'lang:users_image', "trim|callback_image[$id]");
        if ($this->form_validation->run() == false) {
            $this->load->view("admin/news/manage", $data);
        } else {
            $this->news_model->title = $this->input->post('title');
            $this->news_model->content = $this->input->post('content');
            $this->news_model->datetime = date('Y-m-d H:i:s');
            $news_id = $this->news_model->save();
            if ($id)
                $this->report->set('{report_update_news} #' . $id);
            else
                $this->report->set('{report_insert_news} #' . $news_id);
            redirect("admin/news/index");
        }
    }

    public function delete($id = false) {
        if (!$id)
            show_404();
        $this->news_model->news_id = $id;
        if ($this->input->get("title"))
            $this->news_model->title = $this->input->get("title");
        if ($this->input->get("content"))
            $this->news_model->content = $this->input->get("content");
        if ($this->input->get("datetime"))
            $this->news_model->datetime = $this->input->get("datetime");

        if (!$this->news_model->delete())
            show_404();
        $this->report->set('{report_delete_news} #' . $id);
        redirect("admin/news/index");
    }

    public function search() {
        if ($this->input->get("news_id"))
            $this->news_model->news_id = $this->input->get("news_id");
        if ($this->input->get("title"))
            $this->news_model->title = $this->input->get("title");
        if ($this->input->get("content"))
            $this->news_model->content = $this->input->get("content");
        if ($this->input->get("datetime"))
            $this->news_model->datetime = $this->input->get("datetime");
    }
    
    public function image($var, $id) {
        $config['upload_path'] = './' . config('uploads_path');
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('image') && !$id) {
            $this->form_validation->set_message('image', $this->upload->display_errors());
            return FALSE;
        } else {
            $data = $this->upload->data();
            if ($data['file_name'])
                $this->news_model->image = $data['file_name'];
        }
    }
}

/* End of file news.php */
/* Location: ./application/controllers/admin/news.php */