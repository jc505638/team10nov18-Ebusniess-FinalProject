<?php

class Categories extends Brightery_Controller {
    public $layout = 'full';
    public $module = 'categories';
    public $model = 'Categories_model';

    public function __construct(){
        parent::__construct();
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];
        $this->permission();
    }

    public function index() {
        $data['items'] = $this->db->select('categories.*, (SELECT COUNT(*) FROM articles WHERE articles.category_id = categories.category_id) AS count')->where('parent', '0')->order_by('order', 'ASC')->get('categories')->result();
        $this->load->view($this->module.'/index', $data);
    }

    public function manage($id = null) {
        $data = array();

        if ($id) {
            $this->{$this->model}->{$this->_primary_key} = $id;
            $data['item'] = $this->{$this->model}->get();
            if (!$data['item'])
                show_404();
        } else {
            $data['item'] = new Std();
        }
        $categories['0'] = '-- Main Category --';
        foreach ($this->db->where('parent', '0')->get('categories')->result() as $category){
            $categories[$category->category_id] = $category->title;
        }
        $data['categories'] = $categories;
        $this->load->library("form_validation");
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules('parent', 'Parent', 'trim|required');

        if ($this->form_validation->run() == FALSE)
            $this->load->view($this->module . '/manage', $data);

        else {
            $this->{$this->model}->title = $this->input->post('title');
            $this->{$this->model}->parent = $this->input->post('parent');    
            $this->{$this->model}->save();
            redirect('admin/' . $this->module);
        }
    }
   
    public function delete($id = null) {
        if( ! $id)
            show_404();
        $this->{$this->model}->{$this->_primary_key} = $id;
        $data['item'] = $this->{$this->model}->get();
        $this->db->where('category_id', $data['item']->category_id)->delete('keywords');
        if( ! $data['item'])
            show_404();
        $this->{$this->model}->delete();
        redirect('admin/'.$this->module);
    }

    public function resort()
    {
        $this->layout = 'ajax';
        foreach($this->input->post('sort') as $banner){
            $this->db->where('category_id', $banner['banner_id'])->update('categories', array(
                'order' => $banner['order']
            ));
        }

    }
   
}
