<?php

class Banners extends Brightery_Controller
{

    public $layout = 'full';
    public $module = 'banners';
    public $model = 'Banners_model';

    public function __construct()
    {
        parent::__construct();
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];
        $this->permission();
    }

    public function index()
    {
        $data['items'] = $this->db->order_by('order', 'ASC')->get('banners')->result();
        $this->load->view($this->module . '/index', $data);
    }

    public function manage($id = null)
    {
        $data = array();
        $data['selected_categories'] = array();
        if ($id) {
            $this->{$this->model}->{$this->_primary_key} = $id;
            $data['item'] = $this->{$this->model}->get();
            if (!$data['item'])
                show_404();
        } else {
            $data['item'] = new Std();
        }
        $data['categories'] = dd2menu('categories', array('category_id' => 'title'), array('parent' => '0'), TRUE);
        if ($id)
            $data['selected_categories'] = @dd2menu('banner_categories', array('category_id' => 'banner_id'), array('banner_id' => $id), TRUE);
        if (!$data['selected_categories'])
            $data['selected_categories'] = array();
        else
            $data['selected_categories'] = array_keys($data['selected_categories']);
        $this->load->library("form_validation");
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules('link', 'Link', 'trim');
        $this->form_validation->set_rules("code", 'Code', "trim");
        $this->form_validation->set_rules("order", 'Order', "trim|numeric");
        $this->form_validation->set_rules("image", 'Image', "trim|callback_image[$id]");

        if ($this->form_validation->run() == FALSE)
            $this->load->view($this->module . '/manage', $data);

        else {
            $this->{$this->model}->title = $this->input->post('title');
            $this->{$this->model}->type = $this->input->post('type');
            $this->{$this->model}->link = $this->input->post('link');
            $this->{$this->model}->code = $this->input->post('code');
            $this->{$this->model}->order = $this->input->post('order');
            $this->{$this->model}->home = $this->input->post('home') == 1 ? 1 : 0;


            $id = $this->{$this->model}->save();

            if ($id) {
                $this->db->where('banner_id', $id)->delete('banner_categories');

                foreach ($this->input->post('category') as $category) {
                    $arr = array(
                        'banner_id' => $id,
                        'category_id' => $category
                    );
                    $this->db->insert('banner_categories', $arr);
                }
            }
            redirect('admin/' . $this->module);
        }
    }

    public function delete($id = null)
    {
        if (!$id)
            show_404();
        $this->{$this->model}->{$this->_primary_key} = $id;
        $data['item'] = $this->{$this->model}->get();
        if (!$data['item'])
            show_404();
        $this->{$this->model}->delete();
        redirect('admin/' . $this->module);
    }

    public function image($var, $id)
    {
        $config['upload_path'] = './cdn/banners/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $this->load->library('upload', $config);
        if ($this->upload->do_upload('image')) {
            $data = $this->upload->data();
            if ($data['file_name'])
                $this->{$this->model}->image = base_url() . '/cdn/banners/' . $data['file_name'];
        }
        return true;
    }

    public function resort()
    {
        $this->layout = 'ajax';
        foreach($this->input->post('sort') as $banner){
            $this->db->where('banner_id', $banner['banner_id'])->update('banners', array(
                'order' => $banner['order']
            ));
        }

    }

}
