<?php

class Keywords extends Brightery_Controller {
    public $layout = 'full';
    public $module = 'keywords';
    public $model = 'Keywords_model';

    public function __construct(){
        parent::__construct();
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];
        $this->permission();
    }

    public function index($id = null) {
          if( ! $id)
            show_404();
        $this->{$this->model}->{'categories.category_id'}  = $id;
        $this->{$this->model}->custom_select  = 'keywords.*, categories.title as name';
        $this->{$this->model}->joins = array(
            'categories' => array('categories.category_id = keywords.category_id', 'inner')
        );
        $data['id'] = $id;
        $data['items'] = $this->{$this->model}->get();
        $this->load->view($this->module.'/index', $data);
    }

    public function manage($id = null) {
        $data = array();

        if ($id) {
            $this->{$this->model}->{$this->_primary_key} = $id;
            $data['item'] = $this->{$this->model}->get();
            if (!$data['item'])
                show_404();
        } else {
            $data['item'] = new Std();
        }
        
        $this->load->library("form_validation");
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules("url", 'URL', "trim|required");
        $this->form_validation->set_rules("page_url", 'Page URL', "trim");
        $this->form_validation->set_rules("page_title", 'Page Title', "trim");
        $this->form_validation->set_rules("page_description", 'Page Description', "trim");
        $this->form_validation->set_rules("page_keywords", 'Page Keywords', "trim");

        if ($this->form_validation->run() == FALSE)
            $this->load->view($this->module . '/manage', $data);

        else {
            $this->{$this->model}->title = $this->input->post('title');
            $this->{$this->model}->url = $this->input->post('url');
            $this->{$this->model}->page_url = $this->input->post('page_url');
            $this->{$this->model}->page_title = $this->input->post('page_title');
            $this->{$this->model}->page_description = $this->input->post('page_description');
            $this->{$this->model}->page_keywords = $this->input->post('page_keywords');
           
            $this->{$this->model}->save();
            redirect('admin/' . $this->module . '/'. 'index' . '/' . $data['item']->category_id);
        }
    }

    public function add($id = null) {
        $data = array();

        $data['item'] = new Std();

        $this->load->library("form_validation");
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules("url", 'URL', "trim|required");
        $this->form_validation->set_rules("page_url", 'Page URL', "trim");
        $this->form_validation->set_rules("page_title", 'Page Title', "trim");
        $this->form_validation->set_rules("page_description", 'Page Description', "trim");
        $this->form_validation->set_rules("page_keywords", 'Page Keywords', "trim");

        if ($this->form_validation->run() == FALSE)
            $this->load->view($this->module . '/manage', $data);

        else {
            $this->{$this->model}->title = $this->input->post('title');
            $this->{$this->model}->category_id = $id;
            $this->{$this->model}->url = $this->input->post('url');
            $this->{$this->model}->page_url = $this->input->post('page_url');
            $this->{$this->model}->page_title = $this->input->post('page_title');
            $this->{$this->model}->page_description = $this->input->post('page_description');
            $this->{$this->model}->page_keywords = $this->input->post('page_keywords');
           
           
            $this->{$this->model}->save();
            redirect('admin/' . $this->module . '/'.'index'.'/'. $id);
        }
    }

    public function delete($id = null) {
        if( ! $id)
            show_404();
        $this->{$this->model}->{$this->_primary_key} = $id;
        $data['item'] = $this->{$this->model}->get();
        if( ! $data['item'])
            show_404();
        $this->{$this->model}->delete();
        redirect('admin/'.$this->module.'/'.'index'.'/'.$data['item']->category_id);
    }  

}
