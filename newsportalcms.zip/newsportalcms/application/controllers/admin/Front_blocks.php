<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Front_blocks extends CI_Controller {

    public $module = "front_blocks";

    public function __construct() {
        parent::__construct();
        $this->load->model('front_blocks_model');
        $this->lang->load('front_blocks');
        $this->output->enable_profiler(FALSE);
        permission();
    }

    public function index() {
        if (isset($_GET['search']))
            $this->search();
        $data["total_rows"] = $this->front_blocks_model->get(true);
        $this->front_blocks_model->offset = $this->uri->segment("4");
        $this->front_blocks_model->limit = config('per_page');
        $data["items"] = $this->front_blocks_model->get();
        $config['uri_segment'] = 4;
        $config['base_url'] = site_url('admin/front_blocks/index');
        $config['total_rows'] = $data["total_rows"];
        $config['per_page'] = $this->front_blocks_model->limit;
        $config['suffix'] = $this->input->get() ? '?' . http_build_query($_GET) : NULL;
        $this->load->library('pagination');
        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('admin/front_blocks/index', $data);
        $this->report->set('{report_view_front_blocks}' . current_url());
    }

    public function manage($id = FALSE) {
        if (!$id) {
            $data['item'] = new stdClass();
            $data['item']->title = NULL;
            $data['item']->description = NULL;
            $data['item']->image = NULL;
            $data['item']->link = NULL;
            $data['item']->display_order = NULL;
        } else {
            $this->front_blocks_model->front_block_id = $id;
            $data['item'] = $this->front_blocks_model->get();
            if (!$data['item'])
                show_404();
        }
        $this->load->library("form_validation");
        $this->form_validation->set_rules("title", 'lang:front_blocks_title', "trim|required");
        $this->form_validation->set_rules("description", 'lang:front_blocks_description', "trim|required");
        $this->form_validation->set_rules("image", 'lang:front_blocks_image', "trim|callback_image[$id]");
        $this->form_validation->set_rules("link", 'lang:front_blocks_link', "trim|required");
        $this->form_validation->set_rules("display_order", 'lang:front_blocks_display_order', "trim|required|integer");
        if ($this->form_validation->run() == false) {
            $this->load->view("admin/front_blocks/manage", $data);
        } else {
            $this->front_blocks_model->title = $this->input->post('title');
            $this->front_blocks_model->description = $this->input->post('description');
            $this->front_blocks_model->link = $this->input->post('link');
            $this->front_blocks_model->display_order = $this->input->post('display_order');
            $front_block_id = $this->front_blocks_model->save();
            if ($id)
                $this->report->set('{report_update_front_blocks} #' . $id);
            else
                $this->report->set('{report_insert_front_blocks} #' . $front_block_id);
            redirect("admin/front_blocks/index");
        }
    }

    public function delete($id = false) {
        if (!$id)
            show_404();
        $this->front_blocks_model->front_block_id = $id;
        if ($this->input->get("title"))
            $this->front_blocks_model->title = $this->input->get("title");
        if ($this->input->get("description"))
            $this->front_blocks_model->description = $this->input->get("description");
        if ($this->input->get("image"))
            $this->front_blocks_model->image = $this->input->get("image");
        if ($this->input->get("link"))
            $this->front_blocks_model->link = $this->input->get("link");
        if ($this->input->get("display_order"))
            $this->front_blocks_model->display_order = $this->input->get("display_order");

        if (!$this->front_blocks_model->delete())
            show_404();
        $this->report->set('{report_delete_front_blocks} #' . $id);
        redirect("admin/front_blocks/index");
    }

    public function search() {
        if ($this->input->get("front_block_id"))
            $this->front_blocks_model->front_block_id = $this->input->get("front_block_id");
        if ($this->input->get("title"))
            $this->front_blocks_model->title = $this->input->get("title");
        if ($this->input->get("description"))
            $this->front_blocks_model->description = $this->input->get("description");
        if ($this->input->get("image"))
            $this->front_blocks_model->image = $this->input->get("image");
        if ($this->input->get("link"))
            $this->front_blocks_model->link = $this->input->get("link");
        if ($this->input->get("display_order"))
            $this->front_blocks_model->display_order = $this->input->get("display_order");
    }

    public function image($var, $id) {
        $config['upload_path'] = './' . config('uploads_path');
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('image') && !$id) {
            $this->form_validation->set_message('image', $this->upload->display_errors());
            return FALSE;
        } else {
            $data = $this->upload->data();
            if ($data['file_name'])
                $this->front_blocks_model->image = $data['file_name'];
        }
    }

}

/* End of file front_blocks.php */
/* Location: ./application/controllers/admin/front_blocks.php */