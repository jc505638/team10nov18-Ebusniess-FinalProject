<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Links extends CI_Controller {

    public $module = "links";

    public function __construct() {
        parent::__construct();
        $this->load->model('links_model');
        $this->lang->load('links');
        $this->output->enable_profiler(FALSE);
        $this->permission->detect($this->module);
    }

    public function index() {
        if (isset($_GET['search']))
            $this->search();
        $data["total_rows"] = $this->links_model->get(true);
        $this->links_model->offset = $this->uri->segment("4");
        $this->links_model->limit = config('per_page');
        $data["items"] = $this->links_model->get();
        $config['uri_segment'] = 4;
        $config['base_url'] = site_url('admin/links/index');
        $config['total_rows'] = $data["total_rows"];
        $config['per_page'] = $this->links_model->limit;
        $config['suffix'] = $this->input->get() ? '?' . http_build_query($_GET) : NULL;
        $this->load->library('pagination');
        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('admin/links/index', $data);
    }

    public function manage($id = FALSE) {
        if (!$id) {
            $data['item'] = new stdClass();
            $data['item']->link_type_id = NULL;
            $data['item']->name = NULL;
            $data['item']->url = NULL;
            $data['item']->var = NULL;
            $data['item']->visibility_status_id = 1;
        } else {
            $this->links_model->link_id = $id;
            $data['item'] = $this->links_model->get();
        }
        $this->load->library("form_validation");
        $this->form_validation->set_rules("link_type_id", 'lang:links_link_type_id', "trim|required|integer");
        $this->form_validation->set_rules("name", 'lang:links_name', "trim|required");
        $this->form_validation->set_rules("url", 'lang:links_url', "trim|required");
        $this->form_validation->set_rules("var", 'lang:links_var', "trim|required");
        $this->form_validation->set_rules("visibility_status_id", 'lang:links_visibility_status_id', "trim|required|integer");
        if ($this->form_validation->run() == false) {
            $this->load->view("admin/links/manage", $data);
        } else {
            $this->links_model->link_type_id = $this->input->post('link_type_id');
            $this->links_model->name = $this->input->post('name');
            $this->links_model->url = $this->input->post('url');
            $this->links_model->var = $this->input->post('var');
            $this->links_model->visibility_status_id = $this->input->post('visibility_status_id');
            $link_id = $this->links_model->save();
            if ($id)
                $this->report->set('{report_update_links} #' . $id);
            else
                $this->report->set('{report_insert_links} #' . $link_id);
            redirect("admin/links/index");
        }
    }

    public function delete($id = false) {
        if (!$id)
            show_404();
        $this->links_model->link_id = $id;
        if ($this->input->get("link_type_id"))
            $this->links_model->link_type_id = $this->input->get("link_type_id");
        if ($this->input->get("name"))
            $this->links_model->name = $this->input->get("name");
        if ($this->input->get("url"))
            $this->links_model->url = $this->input->get("url");
        if ($this->input->get("var"))
            $this->links_model->var = $this->input->get("var");
        if ($this->input->get("visibility_status_id"))
            $this->links_model->visibility_status_id = $this->input->get("visibility_status_id");

        if (!$this->links_model->delete())
            show_404();
        redirect("admin/links/index");
    }

    public function search() {
        if ($this->input->get("link_id"))
            $this->links_model->link_id = $this->input->get("link_id");
        if ($this->input->get("link_type_id"))
            $this->links_model->link_type_id = $this->input->get("link_type_id");
        if ($this->input->get("name"))
            $this->links_model->name = $this->input->get("name");
        if ($this->input->get("url"))
            $this->links_model->url = $this->input->get("url");
        if ($this->input->get("var"))
            $this->links_model->var = $this->input->get("var");
        if ($this->input->get("visibility_status_id"))
            $this->links_model->visibility_status_id = $this->input->get("visibility_status_id");
    }

}

/* End of file links.php */
/* Location: ./application/controllers/admin/links.php */