<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pages extends Brightery_Controller
{
    public $layout = 'full';
    public $module = 'pages';
    public $model = 'pages_model';

    public function __construct()
    {
        parent::__construct();
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];
        $this->permission();
    }

    public function index()
    {
        $data['items'] = $this->{$this->model}->get();
        $this->load->view($this->module . '/index', $data);
    }

    public function manage($id = NULL)
    {
        $data = array();

        if($id) {
            $this->{$this->model}->{$this->_primary_key} = $id;
            $data['item'] = $this->{$this->model}->get();
            if( ! $data['item'])
                show_404();
        }
        else
        {
            $data['item'] = new Std();
        }
        
        $this->load->library("form_validation");
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules("seo", 'SEO', "trim|required");
        $this->form_validation->set_rules("content", 'Content', 'trim|required');

         if($this->form_validation->run() == FALSE)
            $this->load->view($this->module.'/manage', $data);
         
        else {
            $this->{$this->model}->title = $this->input->post('title');
            $this->{$this->model}->seo = $this->input->post('seo');
            $this->{$this->model}->content = $this->input->post('content');
            $this->{$this->model}->save();
            redirect('admin/' . $this->module);
        }
    }

    public function delete($id = null)
    {
        if (!$id)
            show_404();
        $this->{$this->model}->{$this->_primary_key} = $id;
        $data['item'] = $this->{$this->model}->get();
        if (!$data['item'])
            show_404();
        $this->{$this->model}->delete();
        redirect('admin/' . $this->module);
    }
}
/* End of file users.php */
/* Location: ./application/controllers/admin/users.php */