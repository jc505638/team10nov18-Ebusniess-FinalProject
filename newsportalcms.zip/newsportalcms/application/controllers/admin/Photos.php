<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Photos extends CI_Controller {

    public $module = "photos";

    public function __construct() {
        parent::__construct();
        $this->load->model('photos_model');
        $this->lang->load('photos');
        $this->output->enable_profiler(FALSE);
        permission();
    }

    public function index() {
        if (isset($_GET['search']))
            $this->search();
        $data["total_rows"] = $this->photos_model->get(true);
        $this->photos_model->offset = $this->uri->segment("4");
        $this->photos_model->limit = config('per_page');
        $data["items"] = $this->photos_model->get();
        $config['uri_segment'] = 4;
        $config['base_url'] = site_url('admin/photos/index');
        $config['total_rows'] = $data["total_rows"];
        $config['per_page'] = $this->photos_model->limit;
        $config['suffix'] = $this->input->get() ? '?' . http_build_query($_GET) : NULL;
        $this->load->library('pagination');
        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('admin/photos/index', $data);
        $this->report->set('{report_view_photos}' . current_url());
    }

    public function manage($id = FALSE) {
        if (!$id) {
            $data['item'] = new stdClass();
            $data['item']->title = NULL;
            $data['item']->image = NULL;
            $data['item']->description = NULL;
        } else {
            $this->photos_model->photo_id = $id;
            $data['item'] = $this->photos_model->get();
            if (!$data['item'])
                show_404();
        }
        $this->load->library("form_validation");
        $this->form_validation->set_rules("title", 'lang:photos_title', "trim|required");
        $this->form_validation->set_rules("description", 'lang:photos_description', "trim|required");
        $this->form_validation->set_rules("image", 'lang:photos_image', "trim|callback_image[$id]");
        if ($this->form_validation->run() == false) {
            $this->load->view("admin/photos/manage", $data);
        } else {
            $this->photos_model->title = $this->input->post('title');
            $this->photos_model->description = $this->input->post('description');
            $photo_id = $this->photos_model->save();
            if ($id)
                $this->report->set('{report_update_photos} #' . $id);
            else
                $this->report->set('{report_insert_photos} #' . $photo_id);
            redirect("admin/photos/index");
        }
    }

    public function delete($id = false) {
        if (!$id)
            show_404();
        $this->photos_model->photo_id = $id;
        if ($this->input->get("title"))
            $this->photos_model->title = $this->input->get("title");
        if ($this->input->get("image"))
            $this->photos_model->image = $this->input->get("image");
        if ($this->input->get("description"))
            $this->photos_model->description = $this->input->get("description");

        if (!$this->photos_model->delete())
            show_404();
        $this->report->set('{report_delete_photos} #' . $id);
        redirect("admin/photos/index");
    }

    public function search() {
        if ($this->input->get("photo_id"))
            $this->photos_model->photo_id = $this->input->get("photo_id");
        if ($this->input->get("title"))
            $this->photos_model->title = $this->input->get("title");
        if ($this->input->get("image"))
            $this->photos_model->image = $this->input->get("image");
        if ($this->input->get("description"))
            $this->photos_model->description = $this->input->get("description");
    }

    public function image($var, $id) {
        $config['upload_path'] = './' . config('uploads_path');
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('image') && !$id) {
            $this->form_validation->set_message('image', $this->upload->display_errors());
            return FALSE;
        } else {
            $data = $this->upload->data();
            if ($data['file_name'])
                $this->photos_model->image = $data['file_name'];
        }
    }

}

/* End of file photos.php */
/* Location: ./application/controllers/admin/photos.php */