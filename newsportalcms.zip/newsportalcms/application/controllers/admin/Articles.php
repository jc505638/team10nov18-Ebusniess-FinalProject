<?php

class Articles extends Brightery_Controller
{
    public $layout = 'full';
    public $module = 'articles';
    public $model = 'Articles_model';

    public function __construct()
    {
        parent::__construct();
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];
        $this->permission();
    }

    public function index()
    {
        if ($this->input->get('category_id'))
            $this->{$this->model}->{'articles.category_id'} = $this->input->get('category_id');

        if ($this->input->get('title'))
            $this->{$this->model}->{'search_title'} = $this->input->get('title');

        $this->{$this->model}->custom_select = 'articles.*, categories.title as name';
        $this->{$this->model}->joins = array(
            'categories' => array('categories.category_id = articles.category_id', 'inner')

        );

        $this->load->library('pagination');

        $config['total_rows'] = $this->{$this->model}->get(TRUE);
        $config['suffix'] = '?'.http_build_query($_GET);
        $config['base_url'] = site_url('admin/articles/index');
        $config['per_page'] = config('pagination_limit');
        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();

        if ($this->uri->segment(4))
            $this->{$this->model}->offset = $this->uri->segment(4);

        $data['total'] = $config['total_rows'];
        $this->{$this->model}->limit = config('pagination_limit');
        $data['items'] = $this->{$this->model}->get();
        $this->load->view($this->module . '/index', $data);
    }

    public function manage($id = null)
    {
        $data = array();

        if ($id) {
            $this->{$this->model}->{$this->_primary_key} = $id;
            $data['item'] = $this->{$this->model}->get();
            if (!$data['item'])
                show_404();
        } else {
            $data['item'] = new Std();
            $this->{$this->model}->custom = 1;
            $this->{$this->model}->datetime = date('Y-m-d H:i:s');
        }

        $this->load->library("form_validation");
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
//        $this->form_validation->set_rules('source', 'Source', 'trim|required');
        $this->form_validation->set_rules('url', 'URL', 'trim|required');
        $this->form_validation->set_rules('category_id', 'category', 'trim|required');
        $this->form_validation->set_rules("description", 'Description', "trim|required");
        $this->form_validation->set_rules("image", 'Image', "trim|callback_image[$id]");
        $this->form_validation->set_rules("meta_title", 'Browser Title', "trim");
        $this->form_validation->set_rules("meta_description", 'Description', "trim");

        if ($this->form_validation->run() == FALSE)
            $this->load->view($this->module . '/manage', $data);

        else {
            $this->{$this->model}->title = $this->input->post('title');
//            $this->Articles_model->source = $this->input->post('source');
            $this->{$this->model}->url = $this->input->post('url');
            $this->{$this->model}->category_id = $this->input->post('category_id');
            $this->{$this->model}->description = $this->input->post('description');
            $this->{$this->model}->meta_title = $this->input->post('meta_title');
            $this->{$this->model}->meta_description = $this->input->post('meta_description');

            $this->{$this->model}->save();
            redirect('admin/' . $this->module);
        }
    }

    public function delete($id = null)
    {
        if (!$id)
            show_404();
        $this->{$this->model}->{$this->_primary_key} = $id;
        $data['item'] = $this->{$this->model}->get();
        if (!$data['item'])
            show_404();
        $this->{$this->model}->delete();
        redirect('admin/' . $this->module);
    }

    public function image($var, $id)
    {
        $config['upload_path'] = './cdn/articles/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('image')) {
//            $this->form_validation->set_message('image', $this->upload->display_errors());
            $this->{$this->model}->image = $this->input->post('image_url');
        } else {
            $data = $this->upload->data();
            if ($data['file_name'])
                $this->{$this->model}->image = base_url() . '/cdn/articles/' . $data['file_name'];
        }
        return true;
    }


}
