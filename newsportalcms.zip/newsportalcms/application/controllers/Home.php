<?php

class Home extends Brightery_Controller
{
    public $layout = 'full';
    public $module = 'home';
    public $model = 'articles_model';

    public function __construct()
    {
        parent::__construct();
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];
    }

    public function index()
    {
        // HOME SLIDERS
        $data['sliders'] = $this->db->where('home', '1')->order_by('slider_id', 'desc')->get('sliders')->result();
        $data['articles'] = array();
        $data['_real_articles'] = array();
        $data['real_articles'] = array();
        $categories = $this->db->get('categories')->result();
        $articles_limit_per_category = floor($this->config->item('pagination_limit') / count($categories));

        foreach ($categories as $cat) {
            $this->db->select('articles.*, categories.title as name');
            $this->db->order_by('articles.article_id', 'DESC');
//            $this->db->where('articles.custom', '0');
            $this->db->where('categories.category_id', $cat->category_id);
            $this->db->join('categories', 'categories.category_id = articles.category_id');
            $data['articles'][] = $this->db->get('articles', $articles_limit_per_category)->result();
        }

//        foreach ($categories as $cat) {
//            $this->db->select('articles.*, categories.title as name');
//            $this->db->order_by('articles.article_id', 'DESC');
//            $this->db->where('articles.custom', '1');
//            $this->db->where('categories.category_id', $cat->category_id);
//            $this->db->join('categories', 'categories.category_id = articles.category_id');
//            $data['_real_articles'][] = $this->db->get('articles', $articles_limit_per_category)->result();
//        }

        for ($i = 0; $i < $articles_limit_per_category; $i++) {
            for ($c = 0; $c < count($categories); $c++) {
                if (isset($data['articles'][$c][$i]))
                    $data['items'][] = $data['articles'][$c][$i];
            }
        }

//        for ($i = 0; $i < $articles_limit_per_category; $i++) {
//            for ($c = 0; $c < count($categories); $c++) {
//                if (isset($data['_real_articles'][$c][$i]))
//                    $data['real_articles'][] = $data['_real_articles'][$c][$i];
//            }
//        }

        // HOME BANNERS
        $limit = floor(count($data['items']) / config('ad'));
        $data['ads'] = $this->db->where('home', '1')->get('banners', $limit)->result();

        // LATEST CATEGORY NEWS
        $rand_cats = unserialize(config('random_cats'));
        $cat_id = $rand_cats[array_rand($rand_cats)];
        $data['lcn_category'] = $this->db->where('category_id', $cat_id)->get('categories')->row();
        if ($data['lcn_category'])
            $data['lcn'] = $this->db->order_by('articles.article_id', 'DESC')
                ->where('articles.category_id', $data['lcn_category']->category_id)
                ->get('articles', config('num_of_articles'))
                ->result();
        $this->load->view($this->module, $data);
    }


}
