<?php

class Article extends Brightery_Controller
{

    public $layout = 'full';
    public $module = 'article';
    public $model = 'Articles_model';

    public function __construct()
    {
        parent::__construct();
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];
    }

    public function index($id = null)
    {
        $id = (int)$id;
        $data = array();
        $this->{$this->model}->custom_select = 'articles.*, categories.title as name';
        $this->{$this->model}->joins = array(
            'categories' => array('categories.category_id = articles.category_id', 'inner')
        );
        if (!$id)
            show_404();
        $this->{$this->model}->{$this->_primary_key} = $id;
        $data['item'] = $this->{$this->model}->get();

        if (!$data['item'])
            show_404();

        if ($data['item']->meta_title)
            config('title', $data['item']->meta_title);
        if ($data['item']->meta_description)
            config('meta_description', $data['item']->meta_description);
        if ($data['item']->image)
            config('meta_image', $data['item']->image);
        config('meta_title', $data['item']->title);


        $this->load->view($this->module, $data);
    }
    public function go($id = null)
    {
        $this->layout = 'ajax';
        $id = (int)$id;
        $data = array();
        $this->{$this->model}->custom_select = 'articles.*, categories.title as name';
        $this->{$this->model}->joins = array(
            'categories' => array('categories.category_id = articles.category_id', 'inner')
        );
        if (!$id)
            show_404();
        $this->{$this->model}->{$this->_primary_key} = $id;
        $data['item'] = $this->{$this->model}->get();

        if (!$data['item'])
            show_404();

        if ($data['item']->meta_title)
            config('title', $data['item']->meta_title);
        if ($data['item']->meta_description)
            config('meta_description', $data['item']->meta_description);
        if ($data['item']->image)
            config('meta_image', $data['item']->image);
        config('meta_title', $data['item']->title);


        $this->load->view('iframe', $data);
    }
}
