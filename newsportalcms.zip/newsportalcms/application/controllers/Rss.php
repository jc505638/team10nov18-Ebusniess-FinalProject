<?php


class Rss extends Brightery_Controller
{
    public $layout = 'ajax';
    public $module = 'home';
    public $model = 'articles_model';

    public function __construct()
    {
        parent::__construct();

        $this->load->helper('xml');
        $this->load->helper('text');
        $this->load->model($this->model);
        $this->_primary_key = $this->{$this->model}->_primary_keys[0];
    }

    public function index()
    {

        $data['feed_name'] = config('title');
        $data['encoding'] = 'utf-8';
        $data['feed_url'] = site_url('rss');
        $data['page_description'] = config('title') . ' RSS'; // some description
        $data['page_language'] = 'en-en';
        $data['creator_email'] = config('webmaster_email'); // your email
        $data['articles'] = $this->db->get('articles', 50)->result();
        header("Content-Type: application/rss+xml"); // important!
        $this->load->view('rss', $data);
    }


}
