<?php

/**
 * The master controller, it prepare the languages and global configurations
 * 
 * @author  Muhammad El-Saeed <muhammad@el-saeed.info>
 * @version 1.0
 * @link    http://www.brightery.com
 */

class Brightery_Controller extends CI_Controller{
//    public $lang;
//    public $language;
    public $language_id;
    protected $module;
    protected $action;
    protected $hash;
    public function __construct() {
        parent::__construct();
//        if( ! $this->module)
//            $this->module = get_class($this);
//        $this->lang = $this->input->get('lang');
//        $this->load->library('configuration');
//        $this->load->helper('error');
//        $this->load->library('language');
//        $this->load->library('style');
//        $this->load->library('license');
//        $this->license->check_license();
//        $this->language_id = $this->language->languageId;
//        $this->checkModuleStatus();
    }
    private function checkModuleStatus() {
        if( ! $this->db->where('code', $this->module)->where('status', '1')->get('modules')->num_rows())
            error($this->module . " is not an active module");
    }
    protected function permission() {
        if(!session('user_id'))
            redirect('admin/login');
    }
    protected function companyPermission() {
        if(!session('company_id'))
            redirect('company/login');
    }
    
}
