<?php

class Brightery_Config extends CI_Config {
    protected $instance;


    public function __construct(){
        parent::__construct();

    }
}
