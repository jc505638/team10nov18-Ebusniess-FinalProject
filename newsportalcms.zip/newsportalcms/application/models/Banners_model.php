<?php

class Banners_model extends Brightery_model
{
    public $_table = 'banners';
    public $_primary_keys = array('banner_id');
}
