<?php

class Usergroups_model extends Brightery_model
{
    public $_table = 'usergroups';
    public $_primary_keys = array('usergroup_id');


}
