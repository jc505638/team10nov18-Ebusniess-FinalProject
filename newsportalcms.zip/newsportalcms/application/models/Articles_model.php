<?php

class Articles_model extends Brightery_model
{
    public $_table = 'articles';
    public $_primary_keys = array('article_id');
    public $search_title;

    public function get($count = FALSE) {
        if($this->search_title)
            $this->db->like('articles.title', $this->search_title, 'both');
        return parent::get($count);
    }
}
