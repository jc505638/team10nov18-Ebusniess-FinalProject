<?php

class Keywords_model extends Brightery_model
{
    public $_table = 'keywords';
    public $_primary_keys = array('keyword_id');


}
