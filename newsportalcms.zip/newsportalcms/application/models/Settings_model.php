<?php

class Settings_model extends Brightery_model
{
    public $_table = 'settings';
    public $_primary_keys = array('key');


}
