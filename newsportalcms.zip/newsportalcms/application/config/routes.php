<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['admin'] = 'admin/login';
$route['category/(:any)'] = 'category/index/$1';
$route['category/(:any)/(:num)'] = 'category/index/$1/$2';
$route['article/(:any)'] = 'article/index/$1';
