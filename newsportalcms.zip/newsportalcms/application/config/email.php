<?php

$config['protocol'] = 'smtp';
$config['charset'] = 'utf-8';
$config['smtp_host'] = 'smtp.sparkpostmail.com';
$config['smtp_user'] = 'SMTP_Injection';
$config['smtp_pass'] = '3f56e9109ab2e394cb174b20d96ff8e598732a96';
$config['smtp_port'] = '587';
