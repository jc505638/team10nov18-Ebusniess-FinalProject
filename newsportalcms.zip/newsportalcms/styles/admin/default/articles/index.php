<style>
    td.for_uploaded_img {
        text-align: center;
    }

    .uploaded_img {
        width: 75px;
        height: 75px;
        display: block;
        border: 5px solid #fff;
        border-radius: 100%;
    }

    .uploaded_img img {
        width: 100%;
        border-radius: 100%;
        overflow: hidden;
    }
</style>
<div class="page-title">

    <div class="title-env">
        <h1 class="title">Articles</h1>

        <p class="description"></p>
    </div>

    <div class="breadcrumb-env">

        <ol class="breadcrumb bc-1">
            <li>
                <a href="<?= site_url('admin/dashboard') ?>"><i class="fa-home"></i>Dashboard</a>
            </li>
            <li class="active">
                <strong>Articles</strong>
            </li>
        </ol>

    </div>

</div>

<!-- Admin Table-->
<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">List Of Articles (<?= $total ?>)</h3>

        <div class="panel-options">
            <a href="<?php echo site_url('admin/articles/manage'); ?>" class="btn btn-secondary btn-sm"
               style="color:#fff">Add</a>
        </div>
    </div>
    <div class="panel-body">
        <form action="<?= current_url() ?>" class="form-horizontal" >


            <div class="form-group">
                <div class="col-sm-2">
                    Article
                </div>
                <div class="col-sm-10">
                    <?= form_input('title', set_value('title'), ' class="form-control" '); ?>
                </div>
            </div>
            <div class="form-group-separator"></div>
            <div class="form-group">
                <div class="col-sm-2">
                    Category
                </div>
                <div class="col-sm-10">
                    <?= form_dropdown('category_id', dd2menu('categories', array('category_id' => 'title')), set_value('category_id'), ' class="form-control" '); ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <input type="submit" value="Search" class="btn btn-black btn-block btn-icon icon-left" style="float:right; width: 120px;"/>
                </div>
            </div><div class="form-group-separator"></div>
        </form>
        <br/>
        <table class="table table-bordered table-striped" id="datatable_">
            <thead>
            <tr>
                <th>Title</th>
                <th>Operations</th>
            </tr>
            </thead>

            <tbody class="middle-align">
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo $item->title ?></td>
                    <!--<td class="form_uploaded_img"><span class="uploaded_img"><img src="<?= $item->image ?>"> </span></td>-->
                    <td>
                        <a href="<?php echo site_url('admin/articles/manage/' . $item->article_id); ?>"
                           class="btn btn-orange btn-sm btn-icon icon-left">
                            Edit
                        </a>

                        <a href="<?php echo site_url('admin/articles/delete/' . $item->article_id); ?>"
                           class="btn btn-danger btn-sm btn-icon icon-left">
                            Delete
                        </a>
                    </td>
                </tr>
            <?php endforeach ?>
            </tbody>
        </table>
        <?= $pagination ?>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function ($) {
        $("#datatable").dataTable();
    });
</script>

<link rel="stylesheet" href="<?= STYLE_JS ?>/datatables/dataTables.bootstrap.css">
<script src="<?= STYLE_JS ?>/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?= STYLE_JS ?>/datatables/dataTables.bootstrap.js"></script>
<script src="<?= STYLE_JS ?>/datatables/yadcf/jquery.dataTables.yadcf.js"></script>
<script src="<?= STYLE_JS ?>/datatables/tabletools/dataTables.tableTools.min.js"></script>

