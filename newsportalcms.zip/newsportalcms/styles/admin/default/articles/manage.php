<!-- Admin Table-->
<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">Article</h3>
    </div>
    <div class="panel-body">
        <?php if (validation_errors()) : ?>
            <div class="col-md-12">
                <div class="alert alert-danger">
                    <?php echo validation_errors() ?>
                </div>
            </div>
        <?php endif ?>
        <form role="form" class="form-horizontal" role="form" method="post" enctype="multipart/form-data">

            <div class="form-group">
                <label class="col-sm-2 control-label" for="field-1">Article title</label>

                <div class="col-sm-10">
                    <input type="text" class="form-control" placeholder="Title" name="title"
                           value="<?php echo set_value('title', $item->title) ?>">
                </div>
            </div>
            <div class="form-group-separator"></div>

            <div class="form-group">
                <label class="col-sm-2 control-label">Category</label>

                <div class="col-sm-10">
                    <?= form_dropdown('category_id', dd2menu('categories', array('category_id' => 'title')), set_value('category_id', $item->category_id), 'class="form-control"') ?>
                </div>
            </div>
            <div class="form-group-separator"></div>

            
            <div class="form-group">
                <label class="col-sm-2 control-label">Description</label>
                <div class="compose-message-editor col-sm-10">
                    <textarea class="form-control" name="description" id="editor1"><?php echo set_value('lcn[editor1]', $item->description) ?></textarea>
                </div>
            </div>


            <div class="form-group">
                <label class="col-sm-2 control-label" for="field-1">Photo</label>

                <div class="col-sm-10">
                    <input class="form-control" type="file" name="image" >
                </div>
            </div>
            <div class="form-group-separator"></div>
            
            <h3 class="panel-title" style="color: #2c2e2f; font-size: 17px; padding-bottom: 20px; margin-bottom: 20px; border-bottom: 2px solid #f5f5f5;">Meta Tags:</h3>

            <div class="form-group">
                <label class="col-sm-2 control-label" for="field-1"> Browser title</label>

                <div class="col-sm-10">
                    <input class="form-control" type="text" name="meta_title"  placeholder="Browser Title" value="<?php echo set_value('meta_title', $item->meta_title) ?>" >
                </div>
            </div>
            <div class="form-group-separator"></div>
            <div class="form-group">
                <label class="col-sm-2 control-label" for="field-1"> Description</label>

                <div class="col-sm-10">
                    <input class="form-control" type="text" name="meta_description" placeholder="Description" value="<?php echo set_value('meta_description', $item->meta_description) ?>" >
                </div>
            </div>
            <div class="form-group-separator"></div>
            <div class="form-group">
                <label class="col-sm-2 control-label" for="field-1"> Page URL/Slug</label>

                <div class="col-sm-10">
                    <input class="form-control" type="text" name="url" placeholder="Page URL/Slug" value="<?php echo set_value('url', $item->url) ?>" >
                </div>
            </div>
            <div class="form-group-separator"></div>

            

            <div class="form-group">
                <label class="col-sm-2 control-label"></label>

                <div class="col-sm-10">
                    <input type="submit" class="btn btn-secondary " name="submit" value="Submit">
                    <a href="<?php echo site_url('admin/articles/index'); ?>" class="btn btn-danger">Cancel</a>
                </div>
            </div>


        </form>

    </div>
</div>

<script src="<?= STYLE_JS ?>/ckeditor/ckeditor.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        CKEDITOR.replace('editor1');
    });
</script>